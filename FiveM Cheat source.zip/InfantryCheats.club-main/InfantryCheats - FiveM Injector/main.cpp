#include <Windows.h>
#include <iostream>

#include "LL.h"

void main() {
	LL* ll = new LL;
	ll->Inject();
	system("pause");
}